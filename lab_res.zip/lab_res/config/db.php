<?php
// Directory: config/db.php
$host = 'localhost';
$db = 'lab_reschedule';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>