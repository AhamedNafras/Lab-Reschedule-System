<?php
// Directory: coordinator/manage_schedule.php
session_start();
include('../config/db.php');
include('../functions/functions.php');
if (!is_logged_in() || $_SESSION['role'] != 'Coordinator') {
    header('Location: ../login.php');
    exit();
}

echo '<link rel="stylesheet" href="../style.css">';
echo "<h2>Manage Lab Schedule</h2>";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $lab_id = $_POST['lab_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $stmt = $conn->prepare("INSERT INTO Lab_Schedule (LabID, Date, Time) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $lab_id, $date, $time);
    if ($stmt->execute()) {
        echo "<p class='success'>Schedule added successfully!</p>";
    } else {
        echo "<p class='error'>Failed to add schedule.</p>";
    }
}

$result = $conn->query("SELECT * FROM Labs");
echo "<form method='post'>";
echo "<label>Lab:</label> <select name='lab_id'>";
while ($row = $result->fetch_assoc()) {
    echo "<option value='{$row['LabID']}'>{$row['LabName']} ({$row['Location']})</option>";
}
echo "</select><br>";
echo "<label>Date:</label> <input type='date' name='date' required><br>";
echo "<label>Time:</label> <input type='time' name='time' required><br>";
echo "<input type='submit' value='Add Schedule'>";
echo "</form>";

// Show existing schedules
echo "<h3>Existing Schedules</h3>";
$result = $conn->query("SELECT Lab_Schedule.*, Labs.LabName FROM Lab_Schedule JOIN Labs ON Lab_Schedule.LabID = Labs.LabID");
echo "<table><tr><th>Lab</th><th>Date</th><th>Time</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['LabName']}</td><td>{$row['Date']}</td><td>{$row['Time']}</td></tr>";
}
echo "</table>";
?>
