<?php
// Directory: coordinator/review_requests.php
include('../config/db.php');

$result = $conn->query("SELECT * FROM Reschedule_Request WHERE Status='Pending'");
while ($row = $result->fetch_assoc()) {
    echo "<p>RequestID: {$row['RequestID']}, Student: {$row['StudentID']}, Reason: {$row['Reason']}</p>";
    echo "<form method='post'>
        <input type='hidden' name='request_id' value='{$row['RequestID']}'>
        <button name='approve'>Approve</button>
        <button name='reject'>Reject</button>
    </form>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $request_id = $_POST['request_id'];
    $status = isset($_POST['approve']) ? 'Approved' : 'Rejected';
    $conn->query("UPDATE Reschedule_Request SET Status='$status' WHERE RequestID='$request_id'");
    file_put_contents("../logs/reschedule_logs.txt", "[".date('Y-m-d')."] $status request $request_id\n", FILE_APPEND);
}
?>