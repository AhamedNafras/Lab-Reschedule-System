<?php
// Directory: dashboard.php
session_start();
include('config/db.php');
include('functions/functions.php');
if (!is_logged_in()) {
    header('Location: login.php');
    exit();
}

$role = $_SESSION['role'];
echo '<link rel="stylesheet" href="style.css">';
echo "<h1>Welcome to the Dashboard ($role)</h1>";
echo "<ul>";

if ($role == 'Student') {
    echo "<li><a href='student/request_reschedule.php'>Request Lab Reschedule</a></li>";
    echo "<li><a href='student/attendance.php'>View Attendance</a></li>";
    echo "<li><a href='student/notifications.php'>Notifications</a></li>";
}
elseif ($role == 'Coordinator') {
    echo "<li><a href='coordinator/manage_schedule.php'>Manage Lab Schedule</a></li>";
    echo "<li><a href='coordinator/review_requests.php'>Review Requests</a></li>";
    echo "<li><a href='coordinator/forward_to_instructor.php'>Forward to Instructor</a></li>";
    echo "<li><a href='coordinator/notifications.php'>Notifications</a></li>";
}
elseif ($role == 'Instructor') {
    echo "<li><a href='instructor/view_requests.php'>View Requests</a></li>";
    echo "<li><a href='instructor/confirm_schedule.php'>Confirm Schedule</a></li>";
    echo "<li><a href='instructor/attendance_record.php'>Record Attendance</a></li>";
    echo "<li><a href='instructor/notifications.php'>Notifications</a></li>";
}

echo "<li><a href='logout.php'>Logout</a></li>";
echo "</ul>";
?>