<?php
// Directory: functions/functions.php
function is_logged_in() {
    return isset($_SESSION['user_id']);
}
?>