<?php
function send_email($to, $subject, $message) {
    // Dummy email function
    return mail($to, $subject, $message);
}
?>