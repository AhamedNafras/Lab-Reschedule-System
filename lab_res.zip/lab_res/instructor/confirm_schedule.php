<?php
// Directory: instructor/confirm_schedule.php
include('../config/db.php');

$result = $conn->query("SELECT * FROM Reschedule_Request WHERE Status='Approved'");
while ($row = $result->fetch_assoc()) {
    echo "<p>RequestID: {$row['RequestID']}, Student: {$row['StudentID']}, Reason: {$row['Reason']}</p>";
    echo "<form method='post'>
        <input type='hidden' name='request_id' value='{$row['RequestID']}'>
        <button name='confirm'>Confirm Schedule</button>
    </form>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm'])) {
    $request_id = $_POST['request_id'];
    $date = date('Y-m-d');
    file_put_contents("../logs/reschedule_logs.txt", "[$date] Instructor confirmed schedule for request $request_id\n", FILE_APPEND);
}
?>
