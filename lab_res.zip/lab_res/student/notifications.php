<?php
// Directory: student/notifications.php
session_start();
include('../config/db.php');
include('../functions/functions.php');
if (!is_logged_in() || $_SESSION['role'] != 'Student') {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
echo '<link rel="stylesheet" href="../style.css">';
echo "<h2>Notifications</h2>";

$query = "SELECT * FROM Reschedule_Request WHERE StudentID = ? ORDER BY SubmittedDate DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<table><tr><th>Date</th><th>Status</th><th>Message</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $status = $row['Status'];
        $date = $row['SubmittedDate'];
        $message = ($status == 'Approved') ? "Your reschedule request has been approved." : (($status == 'Rejected') ? "Your reschedule request has been rejected." : "Request pending review.");
        echo "<tr><td>$date</td><td>$status</td><td>$message</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>No notifications found.</p>";
}
?>
