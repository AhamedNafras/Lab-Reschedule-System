<?php // Directory: student/request_reschedule.php
session_start();
include('../config/db.php');
include('../functions/functions.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_SESSION['user_id'];
    $schedule_id = $_POST['schedule_id'];
    $reason = $_POST['reason'];
    $date = date('Y-m-d');
    $letter_uploaded = '';

    if (isset($_FILES['approval_letter']) && $_FILES['approval_letter']['error'] == 0) {
        $upload_dir = '../uploads/';
        $file_name = basename($_FILES['approval_letter']['name']);
        $target_path = $upload_dir . $file_name;
        move_uploaded_file($_FILES['approval_letter']['tmp_name'], $target_path);
        $letter_uploaded = 'Yes';
    } else {
        $letter_uploaded = 'No';
    }

    $stmt = $conn->prepare("INSERT INTO Reschedule_Request (StudentID, ScheduleID, Reason, ApprovalLetter, Status, SubmittedDate) VALUES (?, ?, ?, ?, 'Pending', ?)");
    $stmt->bind_param("sssss", $student_id, $schedule_id, $reason, $letter_uploaded, $date);
    $stmt->execute();

    file_put_contents("../logs/reschedule_logs.txt", "[$date] Request submitted by $student_id\n", FILE_APPEND);
    echo "Request submitted!";
}
?>
<form method="post" enctype="multipart/form-data">
    Schedule ID: <input type="text" name="schedule_id" required><br>
    Reason: <textarea name="reason" required></textarea><br>
    Approval Letter: <input type="file" name="approval_letter"><br>
    <input type="submit" value="Submit Request">
</form>